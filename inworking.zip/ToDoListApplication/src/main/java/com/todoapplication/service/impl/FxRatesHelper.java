/*package com.todoapplication.service.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.bnymellon.gsp.enums.GSPError;
import com.bnymellon.gsp.exception.GSPException;
import com.bnymellon.gsp.model.FxRates;
import com.bnymellon.gsp.model.RequestKey;
import com.bnymellon.gsp.model.ResponseStructure;
import com.bnymellon.gsp.model.request.FxRatesRequest;
import com.bnymellon.gsp.model.response.ResponseModel;
import com.bnymellon.gsp.repository.FxRatesRepository;
import com.bnymellon.gsp.util.InputDataProcessingUtility;

@Component
public class FxRatesHelper {

    @Autowired
    private FxRatesRepository fxRateRepository;

    ResponseModel fxRatesModel = new ResponseModel();

    public ResponseModel fetchFx(final FxRatesRequest fxRatesRequest) {
        String valuationDate = fxRatesRequest.getValuationDate();
        String fromCurrency = fxRatesRequest.getFromCurrency();
        String toCurrency = fxRatesRequest.getToCurrency();
        final String[] inputArgs = { valuationDate, fromCurrency, toCurrency };
        final String result = InputDataProcessingUtility.getCombinationKeyForInputs(inputArgs);

        List<Object[]> resultSet;
        switch (result.substring(3)) {
            case "3":
                resultSet = fxRateRepository.findByToCurrencyForLatestDate(toCurrency);
                break;
            case "13":
                resultSet = fxRateRepository.findByToCurrencyForGivenDate(toCurrency,
                        convertDateToYYYYMMMddFormat(valuationDate));
                break;
            case "23":
                resultSet = fxRateRepository.findByToAndFromCurrencyForLatestDate(toCurrency, fromCurrency);
                break;
            case "123":                
                resultSet = fxRateRepository.findByToAndFromCurrencyForGivenDate(toCurrency, fromCurrency,
                        convertDateToYYYYMMMddFormat(valuationDate));
                break;
            default:
                throw new GSPException(GSPError.GSP1001.toString());
        }
        List<FxRates> fxRates = resultSet.stream().map(record -> {
            FxRates fxrate = new FxRates();
            fxrate.setFromCurrency((String) record[0]);
            fxrate.setToCurrency((String) record[1]);
            fxrate.setFxRate(((BigDecimal) record[2]).doubleValue());
            fxrate.setValuationDate(new Date(((Timestamp) record[3]).getTime()));
            return fxrate;
        }).collect(Collectors.toList());

        ResponseModel fxRatesModel = new ResponseModel();
        final ResponseStructure responseStructure = new ResponseStructure();
        responseStructure.setKey(new RequestKey.RequestKeyBuilder().valuationDate(valuationDate)
                .fromCurrency(fromCurrency).toCurrency(toCurrency).build());
        fxRatesModel.setResponses(buildResponseStructure(responseStructure, "00", fxRates));
        fxRatesModel.setTotal(fxRates.size());
        return fxRatesModel;
    }

    private String convertDateToYYYYMMMddFormat(String valuationDate) {
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd-MMM-yyyy");
        try {
            return dateFormat2.format(dateFormat1.parse(valuationDate));
        } catch (ParseException e) {
            throw new GSPException(GSPError.GSP1001.toString());
        }
    }

    private ResponseStructure buildResponseStructure(ResponseStructure responseStructure, final String responseCode,
            final Object record) {
        responseStructure.setStatus(responseCode);
        if (!ObjectUtils.isEmpty(record)) {
            responseStructure.setInfo(record);
            responseStructure.setDescription("FILE INQUIRY SUCCESSFUL");
        } else {
            responseStructure.setInfo(null);
            responseStructure.setDescription("NO MATCHING DATA FOUND");
        }
        return responseStructure;
    }
}
*/
/*package com.todoapplication.service.impl;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bnymellon.gsp.constant.InquiryConstants;
import com.bnymellon.gsp.enums.GSPError;
import com.bnymellon.gsp.exception.GSPException;
import com.bnymellon.gsp.mapper.RequestDataMapper;
import com.bnymellon.gsp.model.AccountOpeningResponse;
import com.bnymellon.gsp.model.AddAccountMarket;
import com.bnymellon.gsp.model.AddAccountMarketRequest;
import com.bnymellon.gsp.model.request.AccountMarketRequest;
import com.bnymellon.gsp.model.request.AccountOpeningRequest;
import com.bnymellon.gsp.model.request.AccountRequest;
import com.bnymellon.gsp.model.response.ResponseModel;
import com.bnymellon.gsp.model.response.ResponseWrapper;
import com.bnymellon.gsp.service.AccountService;
import com.bnymellon.gsp.swagger.dummy.response.SwaggerResponseBodyForAccount;
import com.bnymellon.gsp.swagger.dummy.response.SwaggerResponseBodyForAccountMarket;
import com.bnymellon.gsp.swagger.dummy.response.SwaggerResponseBodyForAccountMarketAdd;
import com.bnymellon.gsp.swagger.dummy.response.SwaggerResponseBodyForAccountOpening;
import com.bnymellon.gsp.swagger.dummy.response.SwaggerResponseBodyForAccountUpdate;
import com.bnymellon.gsp.util.GSPLogger;
import com.bnymellon.gsp.util.InputDataProcessingUtility;
import com.bnymellon.gsp.util.MetadataUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

*//**
 * Controller to manage the Request for fetching result related to accounts
 *
 *//*
@RestController
@Api(value = InquiryConstants.REQ_MAPPING_ACCOUNTS, tags = "Accounts", produces = "application/json, application/xml")
public class AccountsController {

    @Autowired
    AccountService accountsService;

    @Autowired
    RequestDataMapper requestDataMapper;

    @Autowired
    MetadataUtil metaUtil;

    @Autowired
    GSPLogger logger;
    
    @Autowired
    @Qualifier(value="requestValidator")
    Validator validator;

    *//**
     *
     * @param accountNumbers
     * @return ResponseModel
     * @throws Exception
     *//*
    @ApiOperation(value = "Provide Details For Accounts", notes = "Returns Accounts Details in JSON / XML format",
            response = SwaggerResponseBodyForAccount.class, httpMethod = "GET", nickname = "getAccount")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Returns Account Details"),
            @ApiResponse(code = 400,
                    message = "Bad Request: The request could not be understood by the server due to malformed syntax"),
            @ApiResponse(code = 401, message = "Unauthorized: The request requires user authentication"),
            @ApiResponse(code = 403,
                    message = "Forbidden: The server understood the request, but is refusing to fulfill it"),
            @ApiResponse(code = 404, message = "Not Found: The server has not found anything matching the Request-URI"),
            @ApiResponse(code = 412,
                    message = "Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false"),
            @ApiResponse(code = 500, message = "Error While Trying To Fetch the accounts")

    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Comit-Id", dataType = "string", value = "Comit-Id of the consumer",
                    paramType = "header", required = true),
            @ApiImplicitParam(name = "Subscriber-App-Id", dataType = "string",
                    value = "Subscriber Application Id of the consumer", paramType = "header", required = true),
            @ApiImplicitParam(name = "Accept", dataType = "string",
                    value = "Accept Header is used to specify media type {JSON, XML} which are acceptable for the response ",
                    paramType = "header"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_ACCOUNT_NUMBER,
                    value = "Account Number / Comma Separated list of Account Numbers", required = true,
                    dataType = "string", paramType = "query") })
    @RequestMapping(value = "/accounts", method = RequestMethod.GET,
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    public ResponseWrapper<ResponseModel> fetchAccountsByAccountNumber(
            @RequestParam(value = InquiryConstants.PARAM_ACCOUNT_NUMBER, required = true) final String accountNumbers) {
        final List<String> listOfAccountNumbers = InputDataProcessingUtility.getCommaSeparatedInput(accountNumbers);
        final AccountRequest accountRequest = requestDataMapper.prepareAccountRequest(listOfAccountNumbers);
        logger.info("Starting to fetch account using request {}", accountRequest);
        final ResponseModel responseModel = accountsService.fetchAccountsUsingAccountNumber(accountRequest);
        return metaUtil.buildSuccessResponseMapper(responseModel);
    }

    *//**
     * 
     * @param accountMarketRequestBody
     * @return
     *//*
    @ApiOperation(value = "Provide Details For Account Markets",
            notes = "Returns Account Market Details in JSON / XML format",
            response = SwaggerResponseBodyForAccountMarket.class, httpMethod = "GET", nickname = "getAccountMarkets",
            responseContainer = "ResponseWrapper")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Returns Account Market Details",
            response = SwaggerResponseBodyForAccountMarket.class),

            @ApiResponse(code = 400,
                    message = "Bad Request: The request could not be unde.rstood by the server due to malformed syntax"),
            @ApiResponse(code = 401, message = "Unauthorized: The request requires user authentication"),
            @ApiResponse(code = 403,
                    message = "Forbidden: The server understood the request, but is refusing to fulfill it"),
            @ApiResponse(code = 404, message = "Not Found: The server has not found anything matching the Request-URI"),
            @ApiResponse(code = 412,
                    message = "Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false"),
            @ApiResponse(code = 500, message = "Error While Trying To Fetch The AccountMarket Details") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Comit-Id", dataType = "string", value = "Comit-Id of the consumer",
                    paramType = "header", required = true),
            @ApiImplicitParam(name = "Subscriber-App-Id", dataType = "string",
                    value = "Subscriber Application Id of the consumer", paramType = "header", required = true),
            @ApiImplicitParam(name = "Accept", dataType = "string",
                    value = "Accept Header is used to specify media type {JSON, XML} which are acceptable for the response ",
                    paramType = "header"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_ACCOUNT_NUMBER, value = "Single Value Of Account Number",
                    required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_LIMIT,
                    value = "Maximum resultset can return . If limit is greater than default value (also a threshold value) it return no of default value resultset",
                    required = false, dataType = "int", paramType = "query", defaultValue = "20"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_LOC,
                    value = "Alphanumeric 3 digit value which specifies the location of the account market",
                    required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_MARKET_CODE, value = "2 digit value", required = false,
                    dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = InquiryConstants.PARAM_PAGING_KEY,
                    value = "Single value of paging key (It represents if we want to get the next set of transaction responses for the same request)",
                    required = false, dataType = "string", paramType = "query") })
    @RequestMapping(value = InquiryConstants.REQ_MAPPING_ACCOUNT_MARKETS, method = RequestMethod.GET,
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseWrapper<ResponseModel> fetchAccountMarketDetails(
            @RequestParam(value = InquiryConstants.PARAM_ACCOUNT_NUMBER, required = true) final String accountNumber,
            @RequestParam(value = InquiryConstants.PARAM_LIMIT, required = false,
                    defaultValue = "20") final String limit,
            @RequestParam(value = InquiryConstants.PARAM_LOC, required = false) final String location,
            @RequestParam(value = InquiryConstants.PARAM_MARKET_CODE, required = false) final String marketCode,
            @RequestParam(value = InquiryConstants.PARAM_PAGING_KEY, required = false) final String pagingKey) {

        final AccountMarketRequest accountMarketRequest = requestDataMapper.prepareAccountMarketRequest(accountNumber,
                location, marketCode, limit, pagingKey);
        logger.info("Starting to fetch account market details using request {}", accountMarketRequest);
        final ResponseModel responseModel = accountsService.fetchAccountMarketDetails(accountMarketRequest);
        return metaUtil.buildSuccessResponseMapper(responseModel);
    }
    
    *//**
     * 
     * @param accountOpeningRequest
     * @return ResponseModel
     * @throws Exception
     *//*
    
    @ApiOperation(value = "Account Openings",
            notes = "Returns Account Opening Details in JSON / XML format",
            response = SwaggerResponseBodyForAccountOpening.class, httpMethod = "POST", nickname = "accountOpenings",
            responseContainer = "ResponseWrapper")
    @ApiResponses(value = { @ApiResponse(code = 201, message = "Returns Status Details For The Account Number To Be Opened"),
            @ApiResponse(code = 400,
                    message = "Bad Request: The request could not be understood by the server due to malformed syntax"),
            @ApiResponse(code = 401, message = "Unauthorized: The request requires user authentication"),
            @ApiResponse(code = 403,
                    message = "Forbidden: The server understood the request, but is refusing to fulfill it"),
            @ApiResponse(code = 404, message = "Not Found: The server has not found anything matching the Request-URI"),
            @ApiResponse(code = 412,
                    message = "Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Comit-Id", dataType = "string", value = "Comit-Id of the consumer",
                    paramType = "header", required = true),
            @ApiImplicitParam(name = "Subscriber-App-Id", dataType = "string",
                    value = "Subscriber Application Id of the consumer", paramType = "header", required = true),
            @ApiImplicitParam(name = "Accept", dataType = "string",
                    value = "Accept Header is used to specify media type {JSON, XML} which are acceptable for the response ",
                    paramType = "header"),
            })
    @ResponseStatus(value = HttpStatus.CREATED)
    @RequestMapping(value = InquiryConstants.REQ_MAPPING_ACCOUNT_CREATE, method = RequestMethod.POST,
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    public ResponseWrapper<ResponseModel> requestToAccountOpenings(
            @RequestBody AccountOpeningRequest accountOpeningRequest) {
        logger.info("Starting to account opening using request {}", accountOpeningRequest);
        Set<ConstraintViolation<AccountOpeningRequest>> errors = validator.validate(accountOpeningRequest);
        if (!CollectionUtils.isEmpty(errors)) {
            throw new GSPException(GSPError.GSP1001.toString());
        }
        final AccountOpeningResponse accountOpeningResponseModel = accountsService
                .accountOpeningRequest(accountOpeningRequest);

        final ResponseModel accountOpeningRequestResponseModel = new ResponseModel();
        accountOpeningRequestResponseModel.setResponses(accountOpeningResponseModel);
        accountOpeningRequestResponseModel.setTotal(1);
        return metaUtil.buildSuccessResponseMapper(accountOpeningRequestResponseModel);

    }
    
    @ApiOperation(value = "Account Update",
            notes = "Returns Account Update Details in JSON / XML format",
            response = SwaggerResponseBodyForAccountUpdate.class, httpMethod = "PUT", nickname = "accountUpdate",
            responseContainer = "ResponseWrapper")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Returns Status Details For The Account Number To Be Updated"),
            @ApiResponse(code = 400,
                    message = "Bad Request: The request could not be understood by the server due to malformed syntax"),
            @ApiResponse(code = 401, message = "Unauthorized: The request requires user authentication"),
            @ApiResponse(code = 403,
                    message = "Forbidden: The server understood the request, but is refusing to fulfill it"),
            @ApiResponse(code = 404, message = "Not Found: The server has not found anything matching the Request-URI"),
            @ApiResponse(code = 412,
                    message = "Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Comit-Id", dataType = "string", value = "Comit-Id of the consumer",
                    paramType = "header", required = true),
            @ApiImplicitParam(name = "Subscriber-App-Id", dataType = "string",
                    value = "Subscriber Application Id of the consumer", paramType = "header", required = true),
            @ApiImplicitParam(name = "Accept", dataType = "string",
                    value = "Accept Header is used to specify media type {JSON, XML} which are acceptable for the response ",
                    paramType = "header"),
            })
    @RequestMapping(value = InquiryConstants.REQ_MAPPING_ACCOUNT_UPDATE, method = RequestMethod.PUT,
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
   
    public ResponseWrapper<ResponseModel> requestToAccountUpdate(@RequestBody AccountOpeningRequest accountUpdateRequest) {
        logger.info("Starting to Account Update using request {}", accountUpdateRequest);
        Set<ConstraintViolation<AccountOpeningRequest>> errors =validator.validate(accountUpdateRequest);
        if (!CollectionUtils.isEmpty(errors)) {
            throw new GSPException(GSPError.GSP1001.toString());
        }
        final ResponseModel accountUpdateResponseModel = accountsService.accountUpdateRequest(accountUpdateRequest);
        accountUpdateResponseModel.setTotal(1);
        return metaUtil.buildSuccessResponseMapper(accountUpdateResponseModel);
    }

    @ApiOperation(value = "Add Account Market for provided Account Number",
            notes = "Returns Account Market Add Details in JSON / XML format",
            response = SwaggerResponseBodyForAccountMarketAdd.class, httpMethod = "POST", nickname = "addAccountMarkets",
            responseContainer = "ResponseWrapper")
    @ApiResponses(value = { @ApiResponse(code = 201, message = "Returns Status Details For The Account Market To Be Added"),
            @ApiResponse(code = 400,
                    message = "Bad Request: The request could not be understood by the server due to malformed syntax"),
            @ApiResponse(code = 401, message = "Unauthorized: The request requires user authentication"),
            @ApiResponse(code = 403,
                    message = "Forbidden: The server understood the request, but is refusing to fulfill it"),
            @ApiResponse(code = 404, message = "Not Found: The server has not found anything matching the Request-URI"),
            @ApiResponse(code = 412,
                    message = "Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Comit-Id", dataType = "string", value = "Comit-Id of the consumer",
                    paramType = "header", required = true),
            @ApiImplicitParam(name = "Subscriber-App-Id", dataType = "string",
                    value = "Subscriber Application Id of the consumer", paramType = "header", required = true),
            @ApiImplicitParam(name = "Accept", dataType = "string",
                    value = "Accept Header is used to specify media type {JSON, XML} which are acceptable for the response ",
                    paramType = "header"),
            })
    @RequestMapping(value = InquiryConstants.REQ_MAPPING_ACCOUNT_MARKET_ADD, method = RequestMethod.POST,
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseStatus(value = HttpStatus.CREATED)
    public ResponseWrapper<ResponseModel> requestToAddAccountMarkets(@RequestBody AddAccountMarketRequest accountMarketRequest) {
        logger.info("Starting to Add Account Market using request {}", accountMarketRequest);
        Set<ConstraintViolation<AddAccountMarketRequest>> errors =validator.validate(accountMarketRequest);
        if (!CollectionUtils.isEmpty(errors)) {
            throw new GSPException(GSPError.GSP1001.toString());
        }
        final AddAccountMarket addAccountMarketResponse= accountsService.addAccountMarketRequest(accountMarketRequest);
        final ResponseModel accountMarketRequestResponseModel = new ResponseModel();
        accountMarketRequestResponseModel.setResponses(addAccountMarketResponse);
        accountMarketRequestResponseModel.setTotal(1);
        return metaUtil.buildSuccessResponseMapper(accountMarketRequestResponseModel);
       
    }
}
*/
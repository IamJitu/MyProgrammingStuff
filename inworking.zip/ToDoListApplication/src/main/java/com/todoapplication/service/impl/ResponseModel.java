package com.todoapplication.service.impl;

import java.util.Collections;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseModel<T> {

    private List<?> data = Collections.emptyList();

    public List<?> getData() {
        return data;
    }
}

insert into Tasks(taskname,performdate,category,priority,isdone)values('Practice Java.',NOW(),'Activities','HIGH',false);
insert into Tasks(taskname,performdate,category,priority,isdone)values('Read blog articles.',NOW(),'Activities','IMPORTANT',false);
insert into Tasks(taskname,performdate,category,priority,isdone)values('Eat Something.',NOW(),'Other','LOW',false);
insert into Tasks(taskname,performdate,category,priority,isdone)values('Sleep.',NOW(),'Other','MEDIUM',false);
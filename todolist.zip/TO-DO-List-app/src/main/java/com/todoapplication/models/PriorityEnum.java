package com.todoapplication.models;

public enum PriorityEnum {
	LOW, MEDIUM, HIGH, IMPORTANT
}
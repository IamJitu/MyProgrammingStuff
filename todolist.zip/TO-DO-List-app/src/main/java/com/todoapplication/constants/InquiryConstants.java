package com.todoapplication.constants;

public class InquiryConstants {
	
	public static final String REQ_MAPPING_GET_TASKS = "/tasks";
	public static final String REQ_MAPPING_GET_TASKS_BY_ID = "/gettaskbyid";
	public static final String REQ_MAPPING_DELETE_TASKS = "/tasks";
	public static final String REQ_MAPPING_UPDATE_TASKS = "/tasks";
	public static final String REQ_MAPPING_ADD_TASKS = "/tasks";
	public static final String PARAM_TASK_ID = "id";

}

package com.todoapplication.helper;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.todoapplication.models.Tasks;
import com.todoapplication.repositories.TasksRepository;

@Component
public class TasksHelper {

	@Autowired
	private TasksRepository tasksRepository;

	/**
	 * 
	 * @return List Of Tasks
	 */
	public Collection<Tasks> fetchAllTasks() {
		Collection<Tasks> resultSet;
		resultSet = this.tasksRepository.findAllCustom();

		   List<Tasks> Tasks = resultSet.stream().map(record -> {
			   Tasks task = new Tasks();
	            return task;
	        }).collect(Collectors.toList());
		return resultSet;

	}

	/**
	 * 
	 * @param id
	 * @return Task
	 */
	public Tasks getTaskById(long id) {
		return tasksRepository.findOne(id);
	}

	/**
	 * 
	 * @param tasks
	 */
	public void saveTask(Tasks tasks) {
		tasks.setId(null);
		tasksRepository.save(tasks);
	}

	/**
	 * 
	 * @param id
	 */
	public void deleteTask(long id) {
		tasksRepository.delete(id);
	}

	/**
	 * 
	 * @param editedTask
	 * @param id
	 */
	public void editTask(Tasks editedTask, long id) {
		editedTask.setId(id);
		tasksRepository.saveAndFlush(editedTask);
	}
}

package com.todoapplication.service;

import java.util.Collection;

import com.todoapplication.models.Tasks;

public interface TaskCrudService {

	Collection<Tasks> getAllTasks();

	Tasks getTaskById(long id);

	void deleteTask(long id);

	void editTask(Tasks editedTask, long id);

	void saveTask(Tasks task);
}

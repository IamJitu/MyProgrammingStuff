insert into Tasks(taskname,taskdescription,taskpriority,taskstatus,taskarchived)values('Gathering Requirement','Requirement Gathering','MEDIUM','ACTIVE',0);
insert into Tasks(taskname,taskdescription,taskpriority,taskstatus,taskarchived)values('Application Designing','Application Designing','MEDIUM','ACTIVE',0);
insert into Tasks(taskname,taskdescription,taskpriority,taskstatus,taskarchived)values('Implementation','Implementation','MEDIUM','ACTIVE',0);
insert into Tasks(taskname,taskdescription,taskpriority,taskstatus,taskarchived)values('Unit Testing','Unit Testing','LOW','ACTIVE',0);
insert into Tasks(taskname,taskdescription,taskpriority,taskstatus,taskarchived)values('Maintanence','Maintanence','LOW','ACTIVE',0);